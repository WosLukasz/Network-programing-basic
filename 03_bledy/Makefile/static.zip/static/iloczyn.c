#include <stdio.h>

void iloczyn(int a, int b) {
    printf("%d * %d = %d\n", a, b, a*b);
}
