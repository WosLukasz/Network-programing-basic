
void suma(int, int);
void iloczyn(int, int);
