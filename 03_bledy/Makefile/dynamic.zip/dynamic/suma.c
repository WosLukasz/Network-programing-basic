#include <stdio.h>

void suma(int a, int b) {
    printf("%d + %d = %d\n", a, b, a+b);
}
