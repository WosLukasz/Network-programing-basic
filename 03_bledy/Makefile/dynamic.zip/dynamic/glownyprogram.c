#include <stdio.h>
#include "naglowki.h"

int main() {

    suma(2, 3);
    iloczyn(2, 3);
    
    return 0;
}
